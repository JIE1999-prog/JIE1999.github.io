import React, { useState, useEffect } from 'react';
import { Plus, RotateCcw, Target, CalendarCheck, ChevronDown, ChevronUp, Settings2, ListTodo, Star, Sparkles, Bot } from 'lucide-react';
import { DailyProgress, JumpSession, EncouragementData, UserProfile } from './types';
import { CircularProgress } from './components/CircularProgress';
import { RewardModal } from './components/RewardModal';
import { ManualEntryModal } from './components/ManualEntryModal';
import { FutureGoalsPanel } from './components/FutureGoalsPanel';
import { HistoryModal } from './components/HistoryModal';
import { AICoachModal } from './components/AICoachModal';
import { generateEncouragement } from './services/geminiService';

const DEFAULT_TARGET = 1000;
const STORAGE_KEY = 'jump_rope_pro_v1';
const HISTORY_KEY = 'jump_rope_history_v1';
const FUTURE_GOALS_KEY = 'jump_rope_future_goals_v1';
const USER_PROFILE_KEY = 'jump_rope_user_profile_v1';

// Emotional Value Slogans
const EMOTIONAL_SLOGANS = [
  "今天的你，比昨天更耀眼！✨",
  "汗水是脂肪的眼淚，你贏了！💧",
  "這份自律，是你給自己最棒的禮物。🎁",
  "不僅跳過了繩子，更跨越了懶惰。🔥",
  "享受心跳加速的感覺，那是活著的節奏。❤️",
  "堅持很酷，你更酷。😎",
  "你的堅持，終將美好。🌟",
  "每一滴汗水，都是對抗平庸的子彈。🔫",
  "自律即自由，今天的你超自由！🦋",
  "身體知道你的努力，它正在變好。💪"
];

// Format Date Helper
const getTodayString = () => new Date().toISOString().split('T')[0];
const getFormattedDate = (dateString?: string) => {
  const date = dateString ? new Date(dateString) : new Date();
  const options: Intl.DateTimeFormatOptions = { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric', 
    weekday: 'short' 
  };
  return date.toLocaleDateString('zh-TW', options);
};

function App() {
  // State
  const [target, setTarget] = useState<number>(DEFAULT_TARGET);
  const [sessions, setSessions] = useState<JumpSession[]>([]);
  const [history, setHistory] = useState<DailyProgress[]>([]);
  const [futureGoals, setFutureGoals] = useState<Record<string, number>>({});
  const [userProfile, setUserProfile] = useState<UserProfile>({
    name: '',
    age: '',
    height: '',
    weight: '',
    goalWeight: '',
    avatarId: 1,
    avatarUrl: null
  });
  
  const [showReward, setShowReward] = useState(false);
  const [rewardData, setRewardData] = useState<EncouragementData | null>(null);
  const [isLoadingReward, setIsLoadingReward] = useState(false);
  
  // UI State
  const [showSettings, setShowSettings] = useState(false);
  const [settingsTab, setSettingsTab] = useState<'today' | 'plan'>('today');
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [showAICoachModal, setShowAICoachModal] = useState(false);
  const [isCompletedToday, setIsCompletedToday] = useState(false);
  const [showManualModal, setShowManualModal] = useState(false);

  // Initialize Data from LocalStorage
  useEffect(() => {
    const savedData = localStorage.getItem(STORAGE_KEY);
    const savedHistory = localStorage.getItem(HISTORY_KEY);
    const savedFutureGoals = localStorage.getItem(FUTURE_GOALS_KEY);
    const savedProfile = localStorage.getItem(USER_PROFILE_KEY);
    const today = getTodayString();

    // Load History
    let currentHistory: DailyProgress[] = [];
    if (savedHistory) {
      currentHistory = JSON.parse(savedHistory);
      setHistory(currentHistory);
    }

    // Load Future Goals
    let currentFutureGoals: Record<string, number> = {};
    if (savedFutureGoals) {
      currentFutureGoals = JSON.parse(savedFutureGoals);
      setFutureGoals(currentFutureGoals);
    }

    // Load Profile
    if (savedProfile) {
      setUserProfile(JSON.parse(savedProfile));
    }

    if (savedData) {
      const parsed: DailyProgress = JSON.parse(savedData);
      
      // Check if the saved data is from a previous day
      if (parsed.date !== today) {
        // It's a new day! Archive the previous day's data if it's not already in history
        const alreadyArchived = currentHistory.some(h => h.date === parsed.date);
        
        if (!alreadyArchived && parsed.sessions.length > 0) {
          const newHistory = [parsed, ...currentHistory];
          setHistory(newHistory);
          localStorage.setItem(HISTORY_KEY, JSON.stringify(newHistory));
        }

        // Reset for today
        setSessions([]);
        setIsCompletedToday(false);

        // CHECK FUTURE GOALS FOR TODAY
        // IMPORTANT: Check for undefined explicitly because 0 is a valid target (Rest Day)
        if (typeof currentFutureGoals[today] === 'number') {
          setTarget(currentFutureGoals[today]);
        } else {
          // Keep previous target preference
          setTarget(parsed.target);
        }
      } else {
        // It's still today, load data
        setTarget(parsed.target);
        setSessions(parsed.sessions);
        setIsCompletedToday(parsed.isCompleted);
      }
    } else {
      // First time load or cleared data
      if (typeof currentFutureGoals[today] === 'number') {
        setTarget(currentFutureGoals[today]);
      }
    }
  }, []);

  // Save Data to LocalStorage whenever state changes
  useEffect(() => {
    const today = getTodayString();
    const currentTotal = sessions.reduce((sum, s) => sum + s.count, 0);
    // Only mark as completed if target > 0 (not a rest day)
    const completed = target > 0 && currentTotal >= target;
    
    // Check for completion trigger
    if (completed && !isCompletedToday) {
      setIsCompletedToday(true);
      handleGoalReached(currentTotal);
    }

    const dataToSave: DailyProgress = {
      date: today,
      target,
      sessions,
      isCompleted: completed
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(dataToSave));
  }, [sessions, target, isCompletedToday]);

  // Save Future Goals
  useEffect(() => {
    localStorage.setItem(FUTURE_GOALS_KEY, JSON.stringify(futureGoals));
  }, [futureGoals]);

  // Save User Profile
  useEffect(() => {
    localStorage.setItem(USER_PROFILE_KEY, JSON.stringify(userProfile));
  }, [userProfile]);

  const currentTotal = sessions.reduce((sum, s) => sum + s.count, 0);

  const handleGoalReached = async (total: number) => {
    setShowReward(true);
    setIsLoadingReward(true);
    try {
      const data = await generateEncouragement(total);
      setRewardData(data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoadingReward(false);
    }
  };

  const addJumps = (count: number) => {
    const newSession: JumpSession = {
      id: Date.now().toString(),
      count,
      timestamp: Date.now()
    };
    setSessions(prev => [newSession, ...prev]);
  };

  const handleBatchAdd = (count: number, sets: number) => {
    const newSessions: JumpSession[] = [];
    const now = Date.now();
    for (let i = 0; i < sets; i++) {
      newSessions.push({
        id: (now + i).toString(),
        count: count,
        timestamp: now // Same timestamp for batch, or could offset slightly
      });
    }
    setSessions(prev => [...newSessions, ...prev]);
  };

  const updateFutureGoal = (date: string, value: number) => {
    setFutureGoals(prev => ({
      ...prev,
      [date]: value
    }));
  };

  const resetToday = () => {
    if (confirm("確定要重置今日的所有紀錄嗎？")) {
      setSessions([]);
      setIsCompletedToday(false);
    }
  };

  // Helper to get a consistent slogan based on count so it doesn't flicker randomly
  const getSlogan = () => {
    if (!isCompletedToday) return "";
    const index = currentTotal % EMOTIONAL_SLOGANS.length;
    return EMOTIONAL_SLOGANS[index];
  };

  return (
    <div className="min-h-screen pb-10 font-sans selection:bg-pink-500 selection:text-white relative">
      
      {/* Header with Date and History/Coach Buttons */}
      <header className="pt-8 pb-4 px-6 relative">
        {/* Star Button for History/Logs (Left) */}
        <button 
          onClick={() => setShowHistoryModal(true)}
          className="absolute top-8 left-6 w-10 h-10 bg-white/10 backdrop-blur-md border border-white/10 hover:bg-white/20 rounded-full flex items-center justify-center transition-all shadow-lg text-yellow-400 hover:text-yellow-300 active:scale-95 z-20"
          aria-label="查看紀錄"
        >
          <Star size={20} fill="currentColor" />
        </button>

        {/* AI Coach Button (Right) */}
        <button 
          onClick={() => setShowAICoachModal(true)}
          className="absolute top-8 right-6 w-10 h-10 bg-white/10 backdrop-blur-md border border-white/10 hover:bg-white/20 rounded-full flex items-center justify-center transition-all shadow-lg text-violet-300 hover:text-violet-200 active:scale-95 z-20"
          aria-label="AI 教練"
        >
          <Bot size={22} />
        </button>

        <div className="max-w-md mx-auto flex flex-col items-center justify-center text-center">
          <p className="text-blue-200 font-medium mb-1 tracking-widest text-sm uppercase">
            {getFormattedDate()}
          </p>
          <h1 className="font-black text-3xl text-white tracking-tight flex items-center justify-center gap-2">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-200 to-sky-300">
              JumpRope
            </span>
            Pro
          </h1>
        </div>
      </header>

      <main className="max-w-md mx-auto px-6">
        
        {/* Progress Section */}
        <div className="flex flex-col items-center mb-8 mt-4 relative">
          <CircularProgress current={currentTotal} target={target} />
          
          {/* Completion Badge - Only show if target > 0 */}
          {target > 0 && currentTotal >= target && (
              <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-4 bg-white text-yellow-500 px-5 py-2 rounded-full shadow-xl shadow-black/20 flex items-center space-x-2 animate-bounce z-10">
                <CalendarCheck size={18} className="text-yellow-500" />
                <span className="text-sm font-black">今日達標</span>
              </div>
          )}
        </div>

        {/* Emotional Value Slogan - Shown when completed */}
        {target > 0 && currentTotal >= target && (
           <div className="mb-8 -mt-2 animate-pop-in">
             <div className="bg-gradient-to-br from-yellow-50 to-amber-50 border-2 border-yellow-200 rounded-2xl p-4 text-center shadow-sm relative overflow-hidden">
               <div className="absolute top-0 right-0 p-2 opacity-20">
                 <Sparkles className="text-yellow-500 w-12 h-12" />
               </div>
               <p className="text-yellow-800 font-bold text-base relative z-10 leading-relaxed">
                 {userProfile.name ? `${userProfile.name}，` : ""}{getSlogan()}
               </p>
             </div>
           </div>
        )}

        {/* Goal Setting Button */}
        <div className="flex justify-center mb-8">
           <button 
             onClick={() => setShowSettings(!showSettings)}
             className={`flex items-center space-x-2 px-6 py-2.5 rounded-full shadow-lg transition-all duration-300 border backdrop-blur-md ${showSettings ? 'bg-yellow-500/20 border-yellow-400 text-white' : 'bg-white/10 border-white/10 text-yellow-300 hover:bg-white/20 hover:text-white'}`}
           >
             <Target size={18} />
             <span className="font-bold">
                {target === 0 ? "模式: 休息日" : `每日目標: ${target} 下`}
             </span>
             {showSettings ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
           </button>
        </div>

        {/* Settings Panel (Collapsible) */}
        {showSettings && (
          <div className="bg-white rounded-3xl p-6 shadow-2xl mb-8 animate-pop-in">
            {/* Tabs */}
            <div className="flex p-1 bg-slate-100 rounded-xl mb-6">
              <button 
                onClick={() => setSettingsTab('today')}
                className={`flex-1 py-2 text-sm font-bold rounded-lg transition-all flex items-center justify-center ${settingsTab === 'today' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
              >
                <Settings2 size={14} className="mr-1" /> 今日設定
              </button>
              <button 
                onClick={() => setSettingsTab('plan')}
                className={`flex-1 py-2 text-sm font-bold rounded-lg transition-all flex items-center justify-center ${settingsTab === 'plan' ? 'bg-white text-rose-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
              >
                <ListTodo size={14} className="mr-1" /> 未來計畫
              </button>
            </div>

            {settingsTab === 'today' ? (
              <>
                <label className="block text-sm font-bold text-slate-600 mb-4 text-center">
                  調整今日目標
                </label>
                <div className="flex items-center space-x-4">
                  <input 
                    type="range" 
                    min="0" // Allow dragging to 0 manually
                    max="5000" 
                    step="50" 
                    value={target} 
                    onChange={(e) => setTarget(Number(e.target.value))}
                    className="w-full h-3 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600 hover:accent-blue-500"
                  />
                  <div className="bg-blue-50 border border-blue-100 rounded-xl px-4 py-2 min-w-[80px] text-center">
                    <span className="font-black text-blue-600 text-lg">
                      {target === 0 ? "休息" : target}
                    </span>
                  </div>
                </div>
                {target === 0 && (
                  <p className="text-xs text-center text-slate-400 mt-2 font-bold">
                    今日設為休息日，不會計算達標
                  </p>
                )}
                <div className="mt-6 flex justify-center">
                  <button 
                    onClick={resetToday}
                    className="text-xs flex items-center text-rose-500 hover:text-rose-600 font-bold px-4 py-2 bg-rose-50 hover:bg-rose-100 rounded-xl transition-colors"
                  >
                    <RotateCcw size={14} className="mr-1.5" /> 重置今日數據
                  </button>
                </div>
              </>
            ) : (
              <FutureGoalsPanel 
                futureGoals={futureGoals} 
                onUpdateGoal={updateFutureGoal} 
              />
            )}
          </div>
        )}

        {/* Quick Add Buttons Grid */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          {[100, 200, 300, 500].map((num) => {
            const colorClass = 'hover:bg-rose-500 hover:border-rose-400 text-rose-600 hover:text-white';
            return (
             <button
               key={num}
               onClick={() => addJumps(num)}
               className={`flex flex-row items-center justify-center py-5 bg-white border-2 border-transparent rounded-2xl shadow-lg shadow-black/5 ${colorClass} active:scale-95 transition-all duration-200 group relative overflow-hidden`}
             >
               <span className="text-2xl font-black relative z-10">+{num}</span>
             </button>
            )
          })}
        </div>

        {/* Manual Add Button */}
        <button
           onClick={() => setShowManualModal(true)}
           className="w-full mb-8 flex flex-row items-center justify-center py-4 bg-rose-600 rounded-2xl shadow-lg shadow-rose-900/50 active:scale-95 transition-all text-white hover:bg-rose-500 font-bold border border-rose-400"
        >
           <Plus size={20} className="mr-2" />
           手動/批量輸入次數
        </button>

      </main>

      {/* Modals */}
      <ManualEntryModal 
        isOpen={showManualModal}
        onClose={() => setShowManualModal(false)}
        onConfirm={handleBatchAdd}
      />

      <RewardModal 
        isOpen={showReward} 
        onClose={() => setShowReward(false)} 
        data={rewardData}
        isLoading={isLoadingReward}
      />

      <HistoryModal
        isOpen={showHistoryModal}
        onClose={() => setShowHistoryModal(false)}
        sessions={sessions}
        history={history}
        getFormattedDate={getFormattedDate}
        userProfile={userProfile}
        onUpdateProfile={setUserProfile}
      />

      <AICoachModal 
        isOpen={showAICoachModal}
        onClose={() => setShowAICoachModal(false)}
        userProfile={userProfile}
      />
    </div>
  );
}

export default App;