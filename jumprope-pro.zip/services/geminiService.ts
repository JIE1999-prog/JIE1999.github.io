import { GoogleGenAI, Type } from "@google/genai";
import { EncouragementData, UserProfile } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateEncouragement = async (totalJumps: number): Promise<EncouragementData> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `User has just finished a workout of ${totalJumps} jumps with a jump rope. Generate a congratulatory message.`,
      config: {
        systemInstruction: `You are a cheerful, energetic fitness coach. 
        Your goal is to congratulate the user for finishing their daily jump rope goal.
        Return the result in Traditional Chinese (Taiwan usage).
        Format the response as JSON with two fields: 'message' (an enthusiastic short praise) and 'fact' (a very brief, 1-sentence interesting health benefit of jump rope).`,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            message: { type: Type.STRING },
            fact: { type: Type.STRING }
          },
          required: ["message", "fact"]
        }
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error("No response from Gemini");
    }

    return JSON.parse(text) as EncouragementData;
  } catch (error) {
    console.error("Gemini API Error:", error);
    // Fallback if API fails
    return {
      message: "太棒了！你完成了今天的目標！🔥",
      fact: "跳繩 10 分鐘消耗的熱量相當於慢跑 30 分鐘喔！"
    };
  }
};

export const askAICoach = async (question: string, userProfile: UserProfile): Promise<string> => {
  try {
    // Construct user context string
    const profileInfo = `
      User Name: ${userProfile.name || 'Friend'}
      Age: ${userProfile.age || 'Unknown'}
      Height: ${userProfile.height || 'Unknown'} cm
      Weight: ${userProfile.weight || 'Unknown'} kg
      Goal Weight: ${userProfile.goalWeight || 'Unknown'} kg
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: question,
      config: {
        systemInstruction: `You are a professional, encouraging, and friendly Jump Rope Coach named "Ropey AI".
        
        Your Context:
        ${profileInfo}

        Guidelines:
        1. Answer questions about jump rope techniques, safety, weight loss, and fitness schedules.
        2. Keep answers concise (under 150 words usually), easy to read, and practical.
        3. Use Traditional Chinese (Taiwan usage).
        4. Be empathetic. If the user mentions pain, advise rest and seeing a doctor.
        5. Use emojis to be friendly.
        6. Address the user by name if available.
        `,
      }
    });

    return response.text || "抱歉，教練現在有點忙，請稍後再問我一次！💦";
  } catch (error) {
    console.error("Gemini Coach API Error:", error);
    return "網路訊號不佳，教練剛才沒聽清楚，可以再說一次嗎？🤔";
  }
};