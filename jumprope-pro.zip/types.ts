export interface JumpSession {
  id: string;
  count: number;
  timestamp: number;
}

export interface DailyProgress {
  date: string; // YYYY-MM-DD
  target: number;
  sessions: JumpSession[];
  isCompleted: boolean;
}

export interface EncouragementData {
  message: string;
  fact: string;
}

export interface UserProfile {
  name: string; // New field for user name
  age: string;
  height: string;
  weight: string;
  goalWeight: string;
  avatarId?: number; 
  avatarUrl?: string | null; // Base64 string for custom image
}