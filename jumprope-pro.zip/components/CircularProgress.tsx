import React from 'react';
import { Coffee } from 'lucide-react';

interface CircularProgressProps {
  current: number;
  target: number;
  size?: number;
  strokeWidth?: number;
}

export const CircularProgress: React.FC<CircularProgressProps> = ({ 
  current, 
  target, 
  size = 280, 
  strokeWidth = 24 
}) => {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  
  const isRestDay = target === 0;

  // Calculate percentage, max at 100%
  // If rest day, percentage is 0 or 100 visually depending on preference, let's keep it 0 but show specific UI
  const percentage = isRestDay ? 0 : Math.min(100, Math.max(0, (current / target) * 100));
  const offset = circumference - (percentage / 100) * circumference;

  const isCompleted = !isRestDay && percentage >= 100;

  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      {/* Background Circle */}
      <svg width={size} height={size} className="transform -rotate-90 drop-shadow-lg">
        <defs>
          <linearGradient id="completedGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#fef08a" /> {/* Yellow 200 */}
            <stop offset="100%" stopColor="#eab308" /> {/* Yellow 500 */}
          </linearGradient>
        </defs>

        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="rgba(255, 255, 255, 0.1)"
          strokeWidth={strokeWidth}
          fill="transparent"
        />
        {/* Progress Circle */}
        {!isRestDay && (
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            // Changed: Default is white, Completed is Gradient Yellow
            stroke={isCompleted ? "url(#completedGradient)" : "#ffffff"} 
            strokeWidth={strokeWidth}
            fill="transparent"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            className="transition-all duration-1000 ease-out"
          />
        )}
        
        {/* Rest Day Ring (Dashed or Solid color) */}
        {isRestDay && (
           <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="#94a3b8" // Slate-400
            strokeWidth={4}
            fill="transparent"
            strokeDasharray="8 8"
            opacity={0.3}
          />
        )}
      </svg>
      
      {/* Center Text */}
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
        {isRestDay ? (
          <>
             <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mb-2 backdrop-blur-sm">
                <Coffee size={32} className="text-blue-100" />
             </div>
             <span className="text-3xl font-black text-white tracking-tight mb-1">
               休息日
             </span>
             <span className="text-sm text-blue-200 font-bold tracking-wider">
               好好放鬆一下吧
             </span>
          </>
        ) : (
          <>
            <span className="text-sm text-blue-200 font-bold tracking-widest uppercase mb-1">今日累積</span>
            <span 
              className={`text-6xl font-black tracking-tight ${isCompleted ? 'text-transparent bg-clip-text bg-gradient-to-br from-yellow-200 to-yellow-500' : 'text-white'}`} 
              style={{ fontFamily: 'Quicksand, sans-serif' }}
            >
              {current}
            </span>
            <div className="flex items-center space-x-1 mt-2 bg-yellow-500/20 px-3 py-1 rounded-full backdrop-blur-md border border-yellow-400/40">
              <span className="text-yellow-300 font-medium text-sm">目標</span>
              <span className="text-white font-bold text-sm">{target}</span>
            </div>
          </>
        )}
      </div>
    </div>
  );
};