import React, { useState, useRef, useEffect } from 'react';
import { X, Bot, Send, User, Sparkles } from 'lucide-react';
import { UserProfile } from '../types';
import { askAICoach } from '../services/geminiService';

interface AICoachModalProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile;
}

interface Message {
  id: string;
  role: 'user' | 'ai';
  text: string;
}

export const AICoachModal: React.FC<AICoachModalProps> = ({ isOpen, onClose, userProfile }) => {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'ai',
      text: `嗨 ${userProfile.name || '朋友'}！我是你的專屬跳繩教練。想知道怎麼跳得更輕鬆，或是關於減重的建議嗎？隨時問我！💪`
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  if (!isOpen) return null;

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMsg: Message = { id: Date.now().toString(), role: 'user', text: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const responseText = await askAICoach(userMsg.text, userProfile);
      const aiMsg: Message = { id: (Date.now() + 1).toString(), role: 'ai', text: responseText };
      setMessages(prev => [...prev, aiMsg]);
    } catch (error) {
      // Error handled in service, but just in case
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={onClose} />
      
      <div className="relative z-10 bg-white rounded-3xl shadow-2xl w-full max-w-md h-[80vh] flex flex-col animate-pop-in border border-slate-200 overflow-hidden">
        
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-violet-600 to-indigo-600 flex items-center justify-between shrink-0 shadow-md">
          <div className="flex items-center text-white">
            <div className="w-10 h-10 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center mr-3 border border-white/30">
               <Bot size={24} />
            </div>
            <div>
              <h2 className="text-lg font-black tracking-wide">AI 智能教練</h2>
              <p className="text-xs text-violet-200 font-medium flex items-center">
                <span className="w-2 h-2 bg-green-400 rounded-full mr-1.5 animate-pulse"></span>
                在線中
              </p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="p-2 bg-white/10 hover:bg-white/20 rounded-full transition-colors text-white"
          >
            <X size={20} />
          </button>
        </div>

        {/* Chat Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50 scrollbar-hide">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';
            return (
              <div key={msg.id} className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
                {!isUser && (
                   <div className="w-8 h-8 rounded-full bg-violet-100 border border-violet-200 flex items-center justify-center mr-2 shrink-0">
                     <Bot size={16} className="text-violet-600" />
                   </div>
                )}
                <div 
                  className={`max-w-[80%] px-4 py-3 rounded-2xl text-sm leading-relaxed shadow-sm ${
                    isUser 
                    ? 'bg-violet-600 text-white rounded-br-none' 
                    : 'bg-white text-slate-700 border border-slate-200 rounded-bl-none'
                  }`}
                >
                  {msg.text}
                </div>
                {isUser && (
                   <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center ml-2 shrink-0 overflow-hidden">
                     {userProfile.avatarUrl ? (
                       <img src={userProfile.avatarUrl} alt="Me" className="w-full h-full object-cover" />
                     ) : (
                       <User size={16} className="text-slate-500" />
                     )}
                   </div>
                )}
              </div>
            );
          })}
          
          {isLoading && (
            <div className="flex justify-start">
               <div className="w-8 h-8 rounded-full bg-violet-100 border border-violet-200 flex items-center justify-center mr-2">
                 <Bot size={16} className="text-violet-600" />
               </div>
               <div className="bg-white border border-slate-200 px-4 py-3 rounded-2xl rounded-bl-none shadow-sm flex space-x-1 items-center">
                 <div className="w-2 h-2 bg-violet-400 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></div>
                 <div className="w-2 h-2 bg-violet-400 rounded-full animate-bounce" style={{ animationDelay: '0.15s' }}></div>
                 <div className="w-2 h-2 bg-violet-400 rounded-full animate-bounce" style={{ animationDelay: '0.3s' }}></div>
               </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-4 bg-white border-t border-slate-100 shrink-0">
          <form onSubmit={handleSend} className="relative flex items-center">
             <input 
               type="text" 
               value={input}
               onChange={(e) => setInput(e.target.value)}
               placeholder="問教練問題..."
               className="w-full bg-slate-100 text-slate-800 placeholder:text-slate-400 border border-transparent focus:bg-white focus:border-violet-300 rounded-full pl-5 pr-12 py-3.5 outline-none transition-all font-medium"
             />
             <button 
               type="submit"
               disabled={!input.trim() || isLoading}
               className="absolute right-2 p-2 bg-violet-600 hover:bg-violet-700 disabled:bg-slate-300 text-white rounded-full transition-all shadow-md active:scale-95"
             >
               <Send size={18} className={input.trim() ? "ml-0.5" : ""} />
             </button>
          </form>
        </div>
        
      </div>
    </div>
  );
};