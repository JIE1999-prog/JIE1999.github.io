import React, { useEffect, useRef, useState } from 'react';
import { X, Sparkles, Quote, Zap } from 'lucide-react';
import { EncouragementData } from '../types';

interface RewardModalProps {
  isOpen: boolean;
  onClose: () => void;
  data: EncouragementData | null;
  isLoading: boolean;
}

export const RewardModal: React.FC<RewardModalProps> = ({ isOpen, onClose, data, isLoading }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Simple Canvas Confetti Implementation
  useEffect(() => {
    if (isOpen && canvasRef.current) {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;

      // Updated confetti colors to match theme
      const colors = ['#f472b6', '#38bdf8', '#fb7185', '#818cf8', '#a78bfa'];
      const newParticles: any[] = [];

      for (let i = 0; i < 150; i++) {
        newParticles.push({
          x: canvas.width / 2,
          y: canvas.height / 2,
          r: Math.random() * 6 + 2,
          dx: (Math.random() - 0.5) * 12,
          dy: (Math.random() - 0.5) * 12 - 6,
          color: colors[Math.floor(Math.random() * colors.length)],
          gravity: 0.25,
          opacity: 1
        });
      }

      let animationFrameId: number;

      const render = () => {
        if (!ctx) return;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        let activeParticles = 0;

        newParticles.forEach((p) => {
          if (p.opacity > 0) {
            p.x += p.dx;
            p.y += p.dy;
            p.dy += p.gravity;
            p.opacity -= 0.008;

            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fillStyle = p.color;
            ctx.globalAlpha = p.opacity;
            ctx.fill();
            activeParticles++;
          }
        });

        if (activeParticles > 0) {
          animationFrameId = requestAnimationFrame(render);
        }
      };

      render();

      return () => cancelAnimationFrame(animationFrameId);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={onClose} />
      
      {/* Confetti Layer */}
      <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none z-60" />

      <div className="relative z-70 bg-white rounded-[2rem] shadow-2xl max-w-sm w-full p-6 animate-pop-in border-4 border-pink-100 overflow-hidden">
        
        {/* Decorative Background Blob */}
        <div className="absolute -top-12 -right-12 w-40 h-40 bg-pink-200 rounded-full blur-3xl opacity-60 pointer-events-none"></div>
        <div className="absolute -bottom-12 -left-12 w-40 h-40 bg-sky-200 rounded-full blur-3xl opacity-60 pointer-events-none"></div>

        <button 
          onClick={onClose} 
          className="absolute top-4 right-4 p-2 bg-slate-50 hover:bg-slate-100 rounded-full transition-colors text-slate-400 hover:text-slate-600"
        >
          <X size={20} />
        </button>

        <div className="text-center pt-4">
          <div className="mx-auto w-20 h-20 bg-gradient-to-tr from-pink-400 to-rose-400 rounded-full flex items-center justify-center shadow-lg shadow-pink-200 mb-6 transform -rotate-6">
            <Sparkles className="text-white w-10 h-10" />
          </div>

          <h2 className="text-2xl font-black text-slate-800 mb-2">太棒了！目標達成</h2>
          <p className="text-slate-500 mb-6 text-sm font-medium">今天的運動量達標，給自己一個掌聲！</p>

          <div className="bg-gradient-to-br from-sky-50 to-pink-50 rounded-2xl p-5 text-left border border-white shadow-inner relative">
             <Quote className="absolute top-3 right-3 text-sky-200 w-6 h-6" />
             
             {isLoading ? (
               <div className="flex flex-col items-center justify-center py-6 space-y-3">
                 <div className="w-8 h-8 border-4 border-pink-300 border-t-transparent rounded-full animate-spin"></div>
                 <p className="text-xs text-slate-500 font-bold tracking-wide animate-pulse">正在準備你的獎勵...</p>
               </div>
             ) : (
               <>
                 <p className="text-slate-700 font-bold text-lg mb-4 leading-relaxed tracking-wide">
                   {data?.message}
                 </p>
                 <div className="flex items-start space-x-2 text-sky-600 text-xs bg-white p-3 rounded-xl shadow-sm border border-sky-100">
                    <Zap size={16} className="mt-0.5 flex-shrink-0 text-yellow-400 fill-yellow-400" />
                    <span className="font-medium">{data?.fact}</span>
                 </div>
               </>
             )}
          </div>
          
          <button 
            onClick={onClose}
            className="mt-6 w-full py-3.5 bg-slate-800 text-white rounded-2xl font-bold shadow-xl shadow-slate-200 hover:bg-slate-700 active:scale-95 transition-all"
          >
            收下獎勵
          </button>
        </div>
      </div>
    </div>
  );
};