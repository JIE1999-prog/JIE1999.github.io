import React, { useState } from 'react';
import { X, Repeat, CheckCircle } from 'lucide-react';

interface ManualEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (count: number, sets: number) => void;
}

export const ManualEntryModal: React.FC<ManualEntryModalProps> = ({ isOpen, onClose, onConfirm }) => {
  const [count, setCount] = useState<string>('');
  const [sets, setSets] = useState<number>(1);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numCount = parseInt(count);
    if (numCount > 0 && sets > 0) {
      onConfirm(numCount, sets);
      setCount('');
      setSets(1);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={onClose} />
      
      <div className="relative z-10 bg-white rounded-3xl shadow-2xl w-full max-w-sm p-6 animate-pop-in border border-slate-200">
        <button 
          onClick={onClose} 
          className="absolute top-4 right-4 p-2 bg-slate-100 hover:bg-slate-200 rounded-full transition-colors text-slate-500"
        >
          <X size={20} />
        </button>

        <h2 className="text-xl font-black text-slate-800 mb-6 flex items-center">
          <span className="w-10 h-10 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mr-3">
             <Repeat size={20} />
          </span>
          手動/批量輸入
        </h2>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm font-bold text-slate-600 mb-2">
              單次跳繩次數
            </label>
            <input 
              type="number" 
              inputMode="numeric"
              placeholder="例如: 100"
              value={count}
              onChange={(e) => setCount(e.target.value)}
              className="w-full bg-slate-50 border-2 border-slate-200 focus:border-rose-400 focus:ring-0 rounded-xl px-4 py-3 text-lg font-bold text-slate-800 outline-none transition-colors"
              autoFocus
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-slate-600 mb-2 flex justify-between">
              <span>重複組數 (自動輸入)</span>
              <span className="text-rose-500">{sets} 組</span>
            </label>
            <div className="flex items-center space-x-4">
              <input 
                type="range" 
                min="1" 
                max="10" 
                step="1" 
                value={sets} 
                onChange={(e) => setSets(Number(e.target.value))}
                className="w-full h-3 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-rose-600 hover:accent-rose-500"
              />
            </div>
            <p className="text-xs text-slate-400 mt-2 text-right">
              總計將增加: <span className="font-bold text-rose-600 text-lg">{(parseInt(count) || 0) * sets}</span> 下
            </p>
          </div>

          <button 
            type="submit"
            disabled={!count || parseInt(count) <= 0}
            className="w-full py-3.5 bg-rose-600 hover:bg-rose-500 disabled:bg-slate-300 disabled:cursor-not-allowed text-white rounded-2xl font-bold shadow-lg shadow-rose-200 active:scale-95 transition-all flex items-center justify-center"
          >
            <CheckCircle size={20} className="mr-2" />
            確認輸入
          </button>
        </form>
      </div>
    </div>
  );
};