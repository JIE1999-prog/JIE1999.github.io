import React, { useState, useEffect, useRef } from 'react';
import { X, CalendarDays, History, Trophy, Star, User, Ruler, Weight, Activity, Camera, Check, CheckCircle2 } from 'lucide-react';
import { DailyProgress, JumpSession, UserProfile } from '../types';

interface HistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  sessions: JumpSession[];
  history: DailyProgress[];
  getFormattedDate: (dateString?: string) => string;
  userProfile: UserProfile;
  onUpdateProfile: (profile: UserProfile) => void;
}

export const HistoryModal: React.FC<HistoryModalProps> = ({ 
  isOpen, 
  onClose, 
  sessions, 
  history,
  getFormattedDate,
  userProfile,
  onUpdateProfile
}) => {
  const [activeTab, setActiveTab] = useState<'today' | 'history' | 'profile'>('today');
  // Local state for profile editing to allow confirmation before saving
  const [editedProfile, setEditedProfile] = useState<UserProfile>(userProfile);
  const [isSaved, setIsSaved] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync local state when modal opens or prop changes
  useEffect(() => {
    if (isOpen) {
      setEditedProfile(userProfile);
      setIsSaved(false);
    }
  }, [isOpen, userProfile]);

  if (!isOpen) return null;

  const handleProfileChange = (key: keyof UserProfile, value: string) => {
    setEditedProfile({
      ...editedProfile,
      [key]: value
    });
    setIsSaved(false);
  };

  const handleSaveProfile = () => {
    onUpdateProfile(editedProfile);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  const handleAvatarClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditedProfile({
          ...editedProfile,
          avatarUrl: reader.result as string
        });
        setIsSaved(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const getBMI = () => {
    const h = parseFloat(editedProfile.height);
    const w = parseFloat(editedProfile.weight);
    if (h > 0 && w > 0) {
      const bmi = w / ((h / 100) * (h / 100));
      return bmi.toFixed(1);
    }
    return '--';
  };

  const weightDiff = () => {
    const w = parseFloat(editedProfile.weight);
    const g = parseFloat(editedProfile.goalWeight);
    if (w > 0 && g > 0) {
      const diff = w - g;
      if (diff > 0) return `還有 ${diff.toFixed(1)} kg`;
      if (diff < 0) return `已超過目標 ${Math.abs(diff).toFixed(1)} kg`;
      return "已達成目標！";
    }
    return '';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={onClose} />
      
      <div className="relative z-10 bg-white rounded-3xl shadow-2xl w-full max-w-md h-[80vh] flex flex-col animate-pop-in border border-slate-200 overflow-hidden">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-white shrink-0">
          <h2 className="text-xl font-black text-slate-800 flex items-center">
            <span className="w-10 h-10 bg-yellow-100 text-yellow-500 rounded-full flex items-center justify-center mr-3">
               <Star size={20} fill="currentColor" />
            </span>
            個人運動中心
          </h2>
          <button 
            onClick={onClose} 
            className="p-2 bg-slate-100 hover:bg-slate-200 rounded-full transition-colors text-slate-500"
          >
            <X size={20} />
          </button>
        </div>

        {/* Tabs - Reordered to Profile | History | Today */}
        <div className="p-4 bg-slate-50 shrink-0">
          <div className="flex p-1 bg-slate-200/50 rounded-xl">
             <button 
              onClick={() => setActiveTab('profile')}
              className={`flex-1 py-2 text-sm font-bold rounded-lg transition-all flex items-center justify-center ${activeTab === 'profile' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
            >
              <User size={16} className="mr-2" /> 檔案
            </button>
            <button 
              onClick={() => setActiveTab('history')}
              className={`flex-1 py-2 text-sm font-bold rounded-lg transition-all flex items-center justify-center ${activeTab === 'history' ? 'bg-white text-rose-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
            >
              <CalendarDays size={16} className="mr-2" /> 歷史
            </button>
            <button 
              onClick={() => setActiveTab('today')}
              className={`flex-1 py-2 text-sm font-bold rounded-lg transition-all flex items-center justify-center ${activeTab === 'today' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
            >
              <History size={16} className="mr-2" /> 今日
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-white scrollbar-hide">
          
          {/* TAB: TODAY */}
          {activeTab === 'today' && (
            <>
              <div className="flex items-center justify-between mb-2 px-2">
                 <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Today's Logs</span>
                 <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-md">
                   共 {sessions.length} 筆
                 </span>
              </div>
              
              {sessions.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-40 text-slate-400 space-y-2">
                  <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center">
                    <History size={32} className="opacity-20" />
                  </div>
                  <span className="text-sm font-bold">今天還沒有跳繩紀錄喔！</span>
                </div>
              ) : (
                sessions.map((session, index) => (
                  <div key={session.id} className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 border border-slate-100 group hover:border-blue-200 transition-colors">
                     <div className="flex items-center">
                        <div className="w-10 h-10 rounded-full bg-white text-blue-600 shadow-sm flex items-center justify-center text-sm font-black mr-4 border border-slate-100">
                          {sessions.length - index}
                        </div>
                        <div className="flex flex-col">
                           <span className="text-xs text-slate-400 font-bold mb-0.5">時間</span>
                           <span className="text-sm text-slate-600 font-bold">
                             {new Date(session.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                           </span>
                        </div>
                     </div>
                     <div className="text-xl font-black text-slate-700">
                       +{session.count}
                     </div>
                  </div>
                ))
              )}
            </>
          )}

          {/* TAB: HISTORY */}
          {activeTab === 'history' && (
            <>
               <div className="flex items-center justify-between mb-2 px-2">
                 <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Past Records</span>
                 <span className="text-xs font-bold text-pink-600 bg-pink-50 px-2.5 py-1 rounded-md">
                   累積 {history.length} 天
                 </span>
              </div>

              {history.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-40 text-slate-400 space-y-2">
                  <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center">
                    <CalendarDays size={32} className="opacity-20" />
                  </div>
                  <span className="text-sm font-bold">目前還沒有歷史紀錄</span>
                  <span className="text-xs">明天的這時候就有囉！</span>
                </div>
              ) : (
                history.map((record, index) => {
                  const total = record.sessions.reduce((a, b) => a + b.count, 0);
                  return (
                    <div key={index} className={`flex items-center justify-between p-4 rounded-2xl border transition-all ${record.isCompleted ? 'bg-pink-50/50 border-pink-100 hover:bg-pink-50' : 'bg-slate-50 border-slate-100'}`}>
                       <div>
                          <p className="text-xs text-slate-400 font-bold mb-1 uppercase tracking-wide">
                            {getFormattedDate(record.date)}
                          </p>
                          <div className="flex items-baseline space-x-1.5">
                             <span className={`text-2xl font-black ${record.isCompleted ? 'text-pink-500' : 'text-slate-600'}`}>
                               {total}
                             </span>
                             <span className="text-xs text-slate-400 font-bold">/ {record.target} 下</span>
                          </div>
                       </div>
                       
                       {record.isCompleted ? (
                         <div className="flex flex-col items-center justify-center w-12 h-12 bg-gradient-to-br from-pink-400 to-rose-500 rounded-full shadow-lg shadow-pink-200 text-white">
                           <Trophy size={20} />
                         </div>
                       ) : (
                         <div className="flex flex-col items-center justify-center w-12 h-12 bg-slate-200 rounded-full text-slate-400">
                           <span className="text-xs font-bold">未達標</span>
                         </div>
                       )}
                    </div>
                  );
                })
              )}
            </>
          )}

          {/* TAB: PROFILE */}
          {activeTab === 'profile' && (
             <div className="space-y-6 pt-2 pb-6">
                {/* Avatar Section */}
                <div className="flex flex-col items-center justify-center">
                   <div 
                     className="relative group cursor-pointer"
                     onClick={handleAvatarClick}
                   >
                      <input 
                        type="file" 
                        ref={fileInputRef} 
                        onChange={handleFileChange} 
                        className="hidden" 
                        accept="image/*"
                      />
                      <div className="w-28 h-28 rounded-full bg-gradient-to-tr from-blue-300 to-purple-300 p-1 shadow-lg shadow-blue-200">
                        <div className="w-full h-full rounded-full bg-white flex items-center justify-center overflow-hidden">
                           {editedProfile.avatarUrl ? (
                             <img src={editedProfile.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                           ) : (
                             <User size={56} className="text-slate-300" />
                           )}
                        </div>
                      </div>
                      <div className="absolute bottom-1 right-1 bg-slate-800 text-white p-2 rounded-full border-4 border-white shadow-md hover:bg-slate-700 transition-colors">
                         <Camera size={16} />
                      </div>
                   </div>
                   <p className="mt-3 text-xs text-slate-400 font-bold">點擊照片可更換</p>

                   {/* Name Input */}
                   <div className="mt-4 px-8 w-full">
                      <div className="relative">
                         <input 
                           type="text" 
                           value={editedProfile.name}
                           onChange={(e) => handleProfileChange('name', e.target.value)}
                           placeholder="請輸入你的名字..."
                           className="w-full text-center bg-slate-50 border border-slate-100 focus:bg-white focus:border-blue-300 rounded-xl py-3 text-lg font-black text-slate-800 outline-none transition-all placeholder:font-normal"
                         />
                      </div>
                   </div>
                </div>

                {/* Body Stats */}
                <div className="bg-slate-50 rounded-2xl p-5 border border-slate-100">
                   <h3 className="text-sm font-bold text-slate-700 mb-4 flex items-center">
                      <Activity size={16} className="mr-2 text-rose-500" /> 
                      身體數值
                      {getBMI() !== '--' && (
                        <span className="ml-auto text-xs font-black text-rose-500 bg-rose-50 px-2 py-1 rounded">BMI: {getBMI()}</span>
                      )}
                   </h3>
                   <div className="grid grid-cols-2 gap-4">
                      <div>
                         <label className="text-xs font-bold text-slate-400 mb-1 block">年齡</label>
                         <div className="relative">
                            <input 
                              type="number" 
                              value={editedProfile.age}
                              onChange={(e) => handleProfileChange('age', e.target.value)}
                              placeholder="0"
                              className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-slate-700 font-bold focus:border-blue-400 outline-none transition-colors"
                            />
                            <span className="absolute right-3 top-2.5 text-xs text-slate-400 font-bold">歲</span>
                         </div>
                      </div>
                      <div>
                         <label className="text-xs font-bold text-slate-400 mb-1 block">身高</label>
                         <div className="relative">
                            <input 
                              type="number" 
                              value={editedProfile.height}
                              onChange={(e) => handleProfileChange('height', e.target.value)}
                              placeholder="0"
                              className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-slate-700 font-bold focus:border-blue-400 outline-none transition-colors"
                            />
                             <span className="absolute right-3 top-2.5 text-xs text-slate-400 font-bold">cm</span>
                         </div>
                      </div>
                      <div className="col-span-2">
                         <label className="text-xs font-bold text-slate-400 mb-1 block">目前體重</label>
                         <div className="relative">
                             <Weight size={16} className="absolute left-3 top-2.5 text-slate-400" />
                            <input 
                              type="number" 
                              value={editedProfile.weight}
                              onChange={(e) => handleProfileChange('weight', e.target.value)}
                              placeholder="輸入體重..."
                              className="w-full bg-white border border-slate-200 rounded-xl pl-10 pr-10 py-2 text-slate-700 font-bold focus:border-blue-400 outline-none transition-colors"
                            />
                             <span className="absolute right-3 top-2.5 text-xs text-slate-400 font-bold">kg</span>
                         </div>
                      </div>
                   </div>
                </div>

                {/* Goals */}
                <div className="bg-gradient-to-br from-blue-50 to-white rounded-2xl p-5 border border-blue-100">
                    <h3 className="text-sm font-bold text-blue-700 mb-4 flex items-center">
                      <Trophy size={16} className="mr-2" /> 
                      目標設定
                   </h3>
                   <div>
                         <label className="text-xs font-bold text-blue-400 mb-1 block">期望體重</label>
                         <div className="relative">
                            <input 
                              type="number" 
                              value={editedProfile.goalWeight}
                              onChange={(e) => handleProfileChange('goalWeight', e.target.value)}
                              placeholder="輸入目標..."
                              className="w-full bg-white border border-blue-200 rounded-xl px-3 py-3 text-lg text-blue-800 font-black focus:border-blue-400 outline-none placeholder:font-normal transition-colors"
                            />
                            <span className="absolute right-4 top-4 text-sm text-blue-300 font-bold">kg</span>
                         </div>
                         {weightDiff() && (
                           <p className="mt-2 text-xs font-bold text-blue-500 text-right">
                             距離目標: {weightDiff()}
                           </p>
                         )}
                    </div>
                </div>

                {/* Save Button */}
                <div className="pt-2">
                   <button 
                     onClick={handleSaveProfile}
                     disabled={isSaved}
                     className={`w-full py-4 rounded-2xl font-bold shadow-lg transition-all flex items-center justify-center ${
                       isSaved 
                       ? 'bg-green-500 text-white shadow-green-200' 
                       : 'bg-slate-800 text-white shadow-slate-300 hover:bg-slate-700 active:scale-95'
                     }`}
                   >
                     {isSaved ? (
                       <>
                         <CheckCircle2 size={20} className="mr-2" />
                         已儲存設定！
                       </>
                     ) : (
                       <>
                         <Check size={20} className="mr-2" />
                         確認並儲存個人檔案
                       </>
                     )}
                   </button>
                </div>
             </div>
          )}
        </div>
      </div>
    </div>
  );
};