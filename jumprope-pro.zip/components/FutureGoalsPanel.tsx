import React from 'react';
import { CalendarDays, Coffee, Dumbbell, Zap, Edit3 } from 'lucide-react';

interface FutureGoalsPanelProps {
  futureGoals: Record<string, number>;
  onUpdateGoal: (date: string, target: number) => void;
}

export const FutureGoalsPanel: React.FC<FutureGoalsPanelProps> = ({ futureGoals, onUpdateGoal }) => {
  // Generate next 7 days
  const dates = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i + 1); // Start from tomorrow
    return d;
  });

  const getDayName = (date: Date) => {
    return date.toLocaleDateString('zh-TW', { weekday: 'short' });
  };

  const getDateString = (date: Date) => {
    return date.toISOString().split('T')[0];
  };

  const getDisplayDate = (date: Date) => {
    return date.toLocaleDateString('zh-TW', { month: 'numeric', day: 'numeric' });
  };

  // Helper to determine select value
  const getSelectValue = (target: number | undefined) => {
    if (target === 0) return '0';
    if (target === 500) return '500';
    if (target === 1000) return '1000';
    if (target === 2000) return '2000';
    if (target === undefined) return '1000'; // Default to 1000 visual
    return 'custom';
  };

  return (
    <div className="space-y-4 max-h-64 overflow-y-auto pr-2 scrollbar-hide">
      <div className="bg-blue-50/50 rounded-xl p-3 text-xs text-blue-600 mb-2 border border-blue-100 flex items-start">
         <Edit3 size={14} className="mr-2 mt-0.5 flex-shrink-0" />
         在此設定未來的目標，當天會自動套用。選擇「休息日」可暫停打卡目標。
      </div>

      {dates.map((date) => {
        const dateKey = getDateString(date);
        const savedTarget = futureGoals[dateKey];
        const selectValue = getSelectValue(savedTarget);
        const isCustom = selectValue === 'custom';
        
        return (
          <div key={dateKey} className="flex flex-col sm:flex-row sm:items-center justify-between bg-slate-50 p-3 rounded-xl border border-slate-100 gap-3 sm:gap-0">
            <div className="flex items-center space-x-3">
               <div className="flex flex-col items-center bg-white border border-slate-200 rounded-lg p-1.5 min-w-[3.5rem]">
                  <span className="text-[10px] font-bold text-slate-400 uppercase">{getDayName(date)}</span>
                  <span className="text-sm font-black text-slate-700">
                    {date.getDate()}
                  </span>
               </div>
               {savedTarget === 0 && (
                 <span className="text-xs font-bold text-slate-400 bg-slate-200 px-2 py-1 rounded-full flex items-center">
                   <Coffee size={12} className="mr-1" /> 休息日
                 </span>
               )}
            </div>
            
            <div className="flex items-center space-x-2 flex-1 justify-end">
              <div className="relative">
                <select 
                  className={`appearance-none bg-white border ${savedTarget === 0 ? 'border-slate-300 text-slate-500' : 'border-rose-200 text-rose-600'} rounded-xl pl-3 pr-8 py-2 text-sm font-bold outline-none focus:border-rose-400 focus:ring-2 focus:ring-rose-100 transition-all`}
                  value={selectValue}
                  onChange={(e) => {
                    const val = e.target.value;
                    if (val === 'custom') {
                      onUpdateGoal(dateKey, 1000);
                    } else {
                      onUpdateGoal(dateKey, parseInt(val));
                    }
                  }}
                >
                  <option value="0">😴 休息日</option>
                  <option value="500">🌱 輕量 (500)</option>
                  <option value="1000">🏃 標準 (1000)</option>
                  <option value="2000">🔥 挑戰 (2000)</option>
                  <option value="custom">✏️ 自訂...</option>
                </select>
                <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
                  <svg className="w-3 h-3 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M19 9l-7 7-7-7"></path></svg>
                </div>
              </div>

              {isCustom && (
                <div className="flex items-center space-x-1 animate-pop-in">
                  <input 
                    type="number"
                    min="1"
                    step="50"
                    value={savedTarget || ''}
                    onChange={(e) => onUpdateGoal(dateKey, parseInt(e.target.value) || 0)}
                    className="w-20 bg-white border border-rose-200 rounded-xl px-2 py-2 text-center font-bold text-slate-700 focus:border-rose-400 outline-none text-sm"
                  />
                  <span className="text-xs text-slate-400 font-bold whitespace-nowrap">下</span>
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
};